package com.wagwalking;


import com.wagwalking.page.BecomeWalkerPage;
import com.wagwalking.page.HomePage;
import com.wagwalking.page.PromotionWalkFreePage;
import org.junit.Assert;
import org.junit.Test;

public class BecomeWalkerRequiredFieldTest extends BaseTest {

    private HomePage homePage;
    private PromotionWalkFreePage promotionPage;
    private BecomeWalkerPage walkerPage;

    @Test
    public void testBecomeWalkerRequiredField() {
        homePage = new HomePage(driver);
        walkerPage = homePage.clickBecomeWalkerButton();
        walkerPage.clickApplyNowButton();



        String firstNameNote = walkerPage.getFirstNameError();
        Assert.assertEquals("First name cannot be blank", firstNameNote);

        String lastNameNote = walkerPage.getLastNameError();
        Assert.assertEquals("Last name cannot be blank", lastNameNote);

        String emailNote = walkerPage.getValidEmailError();
        Assert.assertEquals("Enter a valid email address", emailNote);

        String phoneNote = walkerPage.getValidPhoneError();
        Assert.assertEquals("Enter a valid phone number", phoneNote);














    }





















}
