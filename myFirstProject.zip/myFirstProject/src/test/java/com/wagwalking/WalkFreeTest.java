package com.wagwalking;

import com.wagwalking.page.HomePage;
import com.wagwalking.page.PromotionWalkFreePage;
import org.junit.Test;

public class WalkFreeTest extends BaseTest {

    private HomePage homePage;
    private PromotionWalkFreePage promotionPage;


    @Test
    public void testWalkFree() {

         homePage = new HomePage(driver);

         promotionPage = homePage.clickWalkFreeButton();


        promotionPage.inputEmail(user1.getEmail());
        promotionPage.inputPassword(user1.getPassword());
        promotionPage.inputPassword(user1.getPassword());
        promotionPage.inputFirstName(user1.getFirstName());
        promotionPage.inputLastName(user1.getLastName());
        promotionPage.inputPhone(user1.getPhone());




    }




















}
