package com.wagwalking;

import com.wagwalking.page.HomePage;
import com.wagwalking.page.PromotionWalkFreePage;
import org.junit.Assert;
import org.junit.Test;

public class ForbidDuplicateEmailTest extends BaseTest {

    private HomePage homePage;
    private PromotionWalkFreePage promotionPage;


    @Test
    public void testForbidDuplicateEmail() throws InterruptedException {

        homePage = new HomePage(driver);

        promotionPage = homePage.clickWalkFreeButton();



        promotionPage.inputEmail("alex@gmail.com");
        promotionPage.inputPassword("54asdadeAwqd");
        promotionPage.inputFirstName("Blabla");
        promotionPage.inputLastName("Doe");
        promotionPage.inputPhone("4086546741");
        promotionPage.clickNextButton();

        Thread.sleep(3000);



        String duplicateEmailNote = promotionPage.getEmailAlreadyRegisteredNote();
        Assert.assertEquals("Email address already registered", duplicateEmailNote);


    }

    //added ForbidDuplicateEmailTest - contains error

































}
