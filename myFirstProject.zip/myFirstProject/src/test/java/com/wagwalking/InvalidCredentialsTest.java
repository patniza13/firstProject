package com.wagwalking;

import com.wagwalking.page.BecomeWalkerPage;
import com.wagwalking.page.HomePage;
import com.wagwalking.page.LoginPage;
import com.wagwalking.page.PromotionWalkFreePage;
import org.junit.Test;

public class InvalidCredentialsTest extends BaseTest {

    private HomePage homePage;
    private PromotionWalkFreePage promotionPage;
    private BecomeWalkerPage walkerPage;
    private LoginPage loginPage;


    @Test
    public void testInvalidCredentials() {
        homePage = new HomePage(driver);
        loginPage = homePage.clickLoginButton();
        loginPage.inputEmail("alex@gmail.com");
        loginPage.inputPassword("123asdfggg");
        loginPage.clickFinalLoginButton();



    }







}
