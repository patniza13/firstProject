package com.wagwalking;

import com.wagwalking.page.HomePage;
import com.wagwalking.page.LoginPage;
import org.junit.Assert;
import org.junit.Test;
import org.openqa.selenium.WebElement;


public class ValidEmailTest extends BaseTest {

    private HomePage homePage;
    private LoginPage promotionPage;



    @Test

    public void testValidEmail() {
        homePage = new HomePage(driver);
        promotionPage = homePage.clickLoginButton();
        promotionPage.inputEmail("111122554");


     //   WebElement errorEmail = promotionPage.
       // Assert.assertEquals("Email address already registered", duplicateEmailNote);




    }

}




