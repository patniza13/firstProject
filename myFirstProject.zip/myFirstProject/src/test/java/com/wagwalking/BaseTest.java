package com.wagwalking;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

    public abstract class BaseTest {

        protected WebDriver driver;
        protected User user1;
        protected User user2;



        @Before
        public void setUp() {

            System.setProperty("webdriver.chrome.driver", "C:\\Users\\Albina Karimova\\Downloads\\chromedriver_win32 (1)\\chromedriver.exe");


            driver = new ChromeDriver();


            driver.get("https://wagwalking.com/");

            System.out.println("Start");

            String actualTitle = driver.getTitle();

            System.out.println(actualTitle);

            String expectedTitle = "WagWalking.com - Leading Local Dog Walker Service for Dog Owners";

            Assert.assertEquals(expectedTitle, actualTitle);

           user1 = new User1("albinalv2016@gmail.com", "Albina", "Saye", "asdadf123546", "7024565457");

           user2 = new User2 ("blabla@gmail.com", "John", "Lennon", "djaksdla987989", "4081234567" );













        }


        @After
        public void quit() {

            System.out.println("Finish");

           // driver.quit();



       }

       //I added new code




















    }
