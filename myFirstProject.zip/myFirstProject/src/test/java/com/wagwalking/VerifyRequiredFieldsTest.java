package com.wagwalking;

import com.wagwalking.page.BasePage;
import com.wagwalking.page.HomePage;
import com.wagwalking.page.PromotionWalkFreePage;
import org.junit.Assert;
import org.junit.Test;

public class VerifyRequiredFieldsTest extends BaseTest {

    private HomePage homePage;
    private PromotionWalkFreePage promotionPage;

    @Test
    public void testVerifyRequiredFields() {

        homePage = new HomePage(driver);

        promotionPage = homePage.clickWalkFreeButton();

        promotionPage.clickEmailField();

        promotionPage.clickPasswordField();

        promotionPage.clickFirstNameField();

        promotionPage.clickLastNameField();

        promotionPage.clickPhoneField();

        promotionPage.clickEmailField();


        String emailNote = promotionPage.getRequiredEmailNote();
        Assert.assertEquals("required", emailNote);


        String firstNameNote = promotionPage.getRequiredFirstNameNote();
        Assert.assertEquals("required", firstNameNote);

        String lastNameNote = promotionPage.getRequiredLastNameNote();
        Assert.assertEquals("required", lastNameNote);

        String phoneNote = promotionPage.getRequiredPhoneNote();
        Assert.assertEquals("required", phoneNote);

        String characterNote = promotionPage.get8Characters();
        Assert.assertEquals("(8 Characters,", characterNote);

        String letterNote = promotionPage.get1Letter();
        Assert.assertEquals("1 Letter,", letterNote);

        String numberNote = promotionPage.get1Number();
        Assert.assertEquals("1 Number)", numberNote);






        //added requiredFieldNote




    }
}
