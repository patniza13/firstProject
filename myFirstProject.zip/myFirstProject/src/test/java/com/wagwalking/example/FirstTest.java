package com.wagwalking.example;
import com.wagwalking.BaseTest;
import org.junit.Assert;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;


public class FirstTest extends BaseTest {

    @Test
    public void testFirst() {





        WebElement walkFreeButton = driver.findElement(By.cssSelector(".sc-ifAKCX.bCMkWd"));

        walkFreeButton.click();


        WebElement emailField =  driver.findElement(By.cssSelector("input[type=\"email\"]"));

        emailField.sendKeys(user1.getEmail());


        WebElement passField = driver.findElement(By.cssSelector("input[type=\"password\"]"));

        passField.sendKeys(user1.getPassword());


        WebElement firstNameField = driver.findElement(By.cssSelector("[name=\"firstName\"]"));

        firstNameField.sendKeys(user1.getFirstName());


        WebElement lastNameField =  driver.findElement(By.cssSelector("[name=\"lastName\"]"));

        lastNameField.sendKeys(user1.getLastName());


        WebElement phoneField = driver.findElement(By.cssSelector("[name=\"phone\"]"));

        phoneField.sendKeys(user1.getPhone());






















    }





    }





































