package com.wagwalking;

import com.wagwalking.page.BecomeWalkerPage;
import com.wagwalking.page.HomePage;
import org.junit.Test;

import java.util.Random;


public class ApplyToBecomeDogWalkerTest extends BaseTest {

    private HomePage homePage;
    private BecomeWalkerPage becomeWalkerPage;

    @Test
    public void testApplyToBecomeDogWalker() throws InterruptedException {
        homePage = new HomePage(driver);
        becomeWalkerPage = homePage.clickBecomeWalkerButton();
        becomeWalkerPage.inputFirstName("Nobody");
        becomeWalkerPage.inputLastName("Doe");
        becomeWalkerPage.inputEmail("john123@gmail.com");
        becomeWalkerPage.inputPhone("4081234567");
        becomeWalkerPage.inputStreetAddress("123");
        Thread.sleep(3000);
        becomeWalkerPage.selectAddress(1);
        Random random = new Random();
        int randomNumber = random.nextInt(5);

      // Random random = new Random();
       // int randomNumber = random.nextInt(4);
        //^^^to pick random num from dropdown list^^^

        becomeWalkerPage.inputApt("11");

        becomeWalkerPage.clickApplyNowButton();

        //added new test







    }
}
