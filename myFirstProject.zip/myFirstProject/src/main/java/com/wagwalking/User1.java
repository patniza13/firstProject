package com.wagwalking;

public class User1 extends User {

    public User1(String email, String firstName, String lastName, String password, String phone) {

        super(email, firstName, lastName, password, phone);
    }


}
