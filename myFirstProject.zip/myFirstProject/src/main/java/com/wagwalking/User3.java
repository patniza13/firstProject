package com.wagwalking;

public class User3 extends User {

    public User3 (String email, String firstName, String lastName, String password, String phone) {
        super(email, firstName, lastName, password, phone);

    }
}
