package com.wagwalking.page;



import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;



import java.util.List;


public class BecomeWalkerPage extends BasePage {

    public BecomeWalkerPage(WebDriver driver) {
        super(driver);
    }

    @FindBy(css = ".button-text")
    private WebElement applyNowButton;

    /*
    [0] - First name cannot be blank
    [1] - Last name cannot be blank
    [2] - Enter a valid email address
    [3] - Enter a valid phone number
     */

    @FindBy(css = ".error-message")
    private List<WebElement> blankMessage;

   @FindBy(css = "#first_name")
   private WebElement firstNameField;

   @FindBy(css = "#last_name")
   private WebElement lastNameField;

   @FindBy(css = "#email")
   private WebElement emailField;

   @FindBy(css = "#phone")
   private WebElement phoneField;

   @FindBy(css = "#address__line-one")
   private WebElement streetAddressField;

   @FindBy(css = ".autocomplete-result")
    private List<WebElement> dropDownAddress;

   @FindBy(css = "#address_line_2")
   private WebElement aptNumberField;




    public String getFirstNameError() {
        return blankMessage.get(0).getText();
    }

    public String getLastNameError() {
        return blankMessage.get(1).getText();
    }

    public String getValidEmailError() {
        return blankMessage.get(2).getText();
    }

    public String getValidPhoneError() {
        return blankMessage.get(3).getText();
    }

    public void inputFirstName(String firstName) {
        firstNameField.sendKeys(firstName);
    }

    public void inputLastName(String lastName) {
        lastNameField.sendKeys(lastName);
    }

    public void inputEmail(String email) {
        emailField.sendKeys(email);
    }

    public void inputPhone(String phone) {
       phoneField.sendKeys(phone);
    }

    public void inputStreetAddress(String streetAddress) {
                                                 // wait.until(ExpectedConditions.visibilityOfAllElements(applyFields));
        streetAddressField.sendKeys(streetAddress);
    }

    public void selectAddress(int i) {
        dropDownAddress.get(i).click();
    }

    public void inputApt(String apt) {
        aptNumberField.sendKeys(apt);
    }


    public void clickApplyNowButton() {
        applyNowButton.click();
    }




























}


