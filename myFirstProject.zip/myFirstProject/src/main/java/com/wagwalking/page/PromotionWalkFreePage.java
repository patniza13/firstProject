package com.wagwalking.page;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.util.List;

public class PromotionWalkFreePage extends BasePage {


    public PromotionWalkFreePage(WebDriver driver) {
        super(driver);
    }

    @FindBy(css = "input[type=\"email\"]")
    private WebElement emailField;

    @FindBy(css = "input[type=\"password\"]")
    private WebElement passwordField;

    @FindBy(css = "input[name=\"firstName\"]")
    private WebElement firstNameField;

    @FindBy(css = "input[name=\"lastName\"]")
    private WebElement lastNameField;

    @FindBy(css = "[name=\"phone\"]")
    private WebElement phoneField;

    @FindBy(css = ".sc-gzVnrw.jvIbBW")
    private WebElement nextButton;

    @FindBy(css = ".sc-bdVaJa.sc-iwsKbI.kOShw" )
    private WebElement emailAlreadyRegisteredNote;



    @FindBy(css = ".sc-bdVaJa.sc-iwsKbI.kOShw")
    private List<WebElement> requiredFields;

    @FindBy(css = "div [class^=\"sc-bdVaJa sc-iwsKbI\"]")
    private WebElement errorMessage;

    /*
    [0] - email required
    [1] - first name required
    [2] - last name required
    [3] - phone required


     */

    @FindBy(css = ".sc-gzVnrw.fzplxK")
    private List<WebElement>  passwordFieldNote;

    /*
    [0] - 8 characters
    [1] - 1 Letter
    [2] - 1 number

     */




    public void inputEmail(String email) {
        emailField.sendKeys(email);

    }

    public void inputPassword (String password) {
        passwordField.sendKeys(password);
    }


    public void inputFirstName (String firstName) {
        firstNameField.sendKeys(firstName);
    }

    public void inputLastName(String lastName) {
        lastNameField.sendKeys(lastName);
    }


    public void inputPhone(String phone) {
        phoneField.sendKeys(phone);
    }

    public void clickEmailField() {
        emailField.click();
    }

    public void clickPasswordField() {
       passwordField.click();
    }


    public void clickFirstNameField() {
        firstNameField.click();


    }

    public void clickLastNameField() {
        lastNameField.click();
    }

    public void clickPhoneField() {
        phoneField.click();

    }

    public void clickNextButton() {
        nextButton.click();


    }



    public String getRequiredEmailNote() {
        return requiredFields.get(0).getText();
    }

    public String getRequiredFirstNameNote() {
        return requiredFields.get(1).getText();
    }

    public String getRequiredLastNameNote() {
        return requiredFields.get(2).getText();
    }

    public String getRequiredPhoneNote() {
        return requiredFields.get(3).getText();
    }

    public String get8Characters() {
        return passwordFieldNote.get(0).getText();
    }

    public String get1Letter(){
        return passwordFieldNote.get(1).getText();

    }

    public String get1Number() {
        return passwordFieldNote.get(2).getText();
    }


    public String getEmailAlreadyRegisteredNote() {
       return emailAlreadyRegisteredNote.getText();
    }

    public String getErrorMessage() {
        return errorMessage.getText();
    }








}
