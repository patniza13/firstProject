package com.wagwalking.page;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.util.List;

public class HomePage extends BasePage {

    public HomePage(WebDriver driver) {
        super(driver);


    }

    @FindBy(css = ".sc-ifAKCX.bCMkWd")
    WebElement walkFreeButton;

    @FindBy(css = ".sc-ifAKCX.jlgKgQ")
    private WebElement becomeWalkerButton;

    @FindBy(css = ".sc-bdVaJa jRHUsQ")
    private WebElement loginButton;

    public PromotionWalkFreePage clickWalkFreeButton() {

        walkFreeButton.click();

       return new PromotionWalkFreePage(driver);


    }

    public BecomeWalkerPage clickBecomeWalkerButton() {

        becomeWalkerButton.click();

        return new BecomeWalkerPage(driver);

    }

    public LoginPage clickLoginButton() {
        loginButton.click();
        return new LoginPage(driver);
    }











}
