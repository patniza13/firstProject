package com.wagwalking;

public abstract class User {

    private String email;
    private String firstName;
    private String lastName;
    private String password;
    private String phone;


    public User (String email, String firstName, String lastName, String password, String phone) {
        this.email = email;
        this.firstName = firstName;
        this.lastName = lastName;
        this.password = password;
        this.phone = phone;

    }

    public String getEmail() {
        return email;

    }

    public String getFirstName() {
        return firstName;

    }

    public String getLastName() {
        return lastName;
    }

    public String getPassword() {
        return password;

    }

    public String getPhone() {
        return phone;
    }




}
