package com.wagwalking;

public class User2 extends User {

    public User2(String email, String firstName, String lastName, String password, String phone) {
        super(email, firstName, lastName, password, phone);
    }
}
